﻿using System;
using System.Collections.Generic;

namespace CollectionsPractice
{
    class Program
    {
        static void Main(string[] args)
        {
// Arrays
            int[] array = {0,1,2,3,4,5,6,7,8,9};
            foreach(int entry in array)
            {
                Console.WriteLine(entry);
            }
            string[] names = {"Tim", "Martin", "Nikki", "Sara"};
            foreach(string name in names)            
            {
                Console.WriteLine(name);
            }
            
            bool[] array3 = new bool[10];
            for (int i=0; i < array3.Length; i++)
            {
                if (i%2 == 0)
                {
                    array3[i]=true;
                }
                else if (i%2 == 1)
                {
                    array3[i]=false;
                }
            }
            foreach(bool truth in array3)            
            {
                Console.WriteLine(truth);
            }
// List
            List<string> flavors = new List<string>() 
            {
                "Chocolate", "Vanilla", "Rocky Road", "Cookie Dough", "Mint Chocolate Chip"
            };
            // Self-Check
            // foreach (string flavor in flavors)
            // {
            //     Console.WriteLine(flavor);
            // }
            Console.WriteLine($"Number of Flavors: {flavors.Count}");
            Console.WriteLine($"The third flavor is: {flavors[2]}");
            flavors.RemoveAt(2);
            // Self-Check
            // foreach (string flavor in flavors)
            // {
            //     Console.WriteLine(flavor);
            // }
            Console.WriteLine($"New Number of Flavors: {flavors.Count}");

// Dictionary
            Dictionary<string, string> likes = new Dictionary<string, string>();
            foreach(var name in names)
            {
                likes.Add(name, null);
            }
            Random rand = new Random();
            foreach(var name in names)
            {
                likes[name]=flavors[(rand.Next(flavors.Count))];
            }
            foreach(var like in likes)
            {
                Console.WriteLine($"{like.Key}'s favorite flavor is {like.Value}.");
            }
        }
    }
}
