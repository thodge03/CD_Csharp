﻿using System;

namespace Basic13
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] ArrayTest = {-1,2,3,4,-5, 0};
            int max = Tasks.FindMax(ArrayTest);
            int[] odds = Tasks.OddArray();
            int gty = Tasks.GreaterThanY(ArrayTest, 1);
        }
    }
}