using System;

namespace Basic13
{
    public static class Tasks
    {
        public static void PrintNumbers()
        {
            for (var i=1;i<=255;i++)
            {
                Console.WriteLine(i);
            }
        }
        public static void PrintOdds()
        {
            for(var i=1;i<=255;i++)
            {
                if(i%2==1)
                    Console.WriteLine(i);
            }
        }
        public static void PrintSum()
        {
            int sum=0;
            for (var i=1;i<=255;i++)
            {
                sum+=i;
                Console.WriteLine($"New Number:{i}  Sum: {sum}");
            }
        }
        public static void LoopArray(int[] numbers)
        {
            foreach (int number in numbers)
            {
                Console.WriteLine(number);
            }
        }
        public static int FindMax(int[] numbers)
        {
            int arrayMax = Int32.MinValue;
            foreach(int number in numbers)
            {
                if (number > arrayMax)
                    arrayMax = number;
            }
            Console.WriteLine($"The max value is {arrayMax}");
            return arrayMax;
        }
        public static void GetAverage(int[] numbers)
        {
            int sum = 0;
            foreach(int number in numbers)
            {
                sum+=number;
            }
            float avg=(float)sum /numbers.Length;
            Console.WriteLine($"The average is: {avg}");
        }
        public static int[] OddArray()
        {
            int length = (255/2)+1;
            int[] odds = new int[length];

            int x = 0;
            for (int oddNum=1;oddNum<=255;oddNum+=2)
            {
                odds[x]=oddNum;
                x++;
            }
            // foreach(int odd in odds)
            // {
            //     Console.WriteLine(odd);
            // }
            return odds;
        }
        public static int GreaterThanY(int[] numbers, int y)
        {
            int gty = 0;
            foreach(int number in numbers)
            {
                if(number > y)
                    gty++;
            }
            // Console.WriteLine($"There are {gty} integers greater than {y}");
            return gty;
        }
        public static void SquareArrayValues(int[] numbers)
        {
            for(int i=0;i<numbers.Length;i++)
            {
                numbers[i] = numbers[i] * numbers[i];
            }
        }
        public static void EliminateNegatives(int[] numbers)
        {
            for(int i=0;i<numbers.Length;i++)
            {
                if (numbers[i] < 0)
                    numbers[i] = 0;  
            }
        }
        public static void MinMaxAverage(int[] numbers)
        {
            int max = Int32.MinValue;
            int min = Int32.MaxValue;
            int sum = 0;

            foreach(int number in numbers)
            {
                sum += number;
                if(number > max)
                    max = number;
                if(number < min)
                    min = number;
            }
            float avg = (float) sum / numbers.Length;
            Console.WriteLine($"Max: {max}");
            Console.WriteLine($"Min: {min}");
            Console.WriteLine($"Average: {avg}");
        }
        public static void ShiftValues(int[] numbers)
        {
            for(int i=0;i<numbers.Length-1;i++)
            {
                numbers[i]=numbers[i+1];
            }
            numbers[numbers.Length-1]= 0;
        }
        public static object[] NumberToString(int[] numbers)
        {
            object[] objArray = new object[numbers.Length];
            for (var i=0;i<numbers.Length;i++)
            {
                if(numbers[i] < 0)
                    objArray[i]="Dojo";
                else
                    objArray[i]=numbers[i];
            }
            return objArray;
        }
    }
}