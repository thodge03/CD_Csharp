﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Dojodachi.Models;
using Microsoft.AspNetCore.Http;

namespace Dojodachi.Controllers
{
    public class HomeController : Controller
    {
        [Route("")]
        [HttpGet]
        public IActionResult Index()
        {
            if(HttpContext.Session.GetString("action")==null)
            {
                HttpContext.Session.SetString("action", "Choose an action.");
            }
            ViewBag.Action = HttpContext.Session.GetString("action");

            if(HttpContext.Session.GetInt32("fullness")==null)
            {
                HttpContext.Session.SetInt32("fullness", 20);
            }
            ViewBag.Fullness = HttpContext.Session.GetInt32("fullness");

            if(HttpContext.Session.GetInt32("happiness")==null)
            {
                HttpContext.Session.SetInt32("happiness", 20);
            }
            ViewBag.Happiness = HttpContext.Session.GetInt32("happiness");

            if(HttpContext.Session.GetInt32("meals")==null)
            {
                HttpContext.Session.SetInt32("meals", 3);
            }
            ViewBag.Meals = HttpContext.Session.GetInt32("meals");
        
            if(HttpContext.Session.GetInt32("energy")==null)
            {
                HttpContext.Session.SetInt32("energy", 50);
            }
            ViewBag.Energy = HttpContext.Session.GetInt32("energy");

            return View();
        }
        [HttpGet("restart")]
        public IActionResult Restart()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }
        
        [HttpGet("feed")]
        public IActionResult Feed()
        {
            int? meal = HttpContext.Session.GetInt32("meals");
            if(meal > 0)
            {
                int newmeal = (int)meal - 1;
                HttpContext.Session.SetInt32("meals", newmeal);
            }
            else
            {
                HttpContext.Session.SetString("action", "You do not have meals to feed your Dojodachi.");
                return RedirectToAction("Index");
            }

            Random r = new Random();
            Random c = new Random();
            int percent = c.Next(1,5);
            if(percent == 1)
            {
                int gained = r.Next(5,11);
                HttpContext.Session.SetString("action", "You fed your Dojodachi and gained " + gained + " fullness. You've also lost one meal.");
                int? oldfull = HttpContext.Session.GetInt32("fullness");
                int newfull = (int)oldfull + gained;
                HttpContext.Session.SetInt32("fullness", newfull);
            }
            else{
                HttpContext.Session.SetString("action", "You fed your Dojodachi and did not gain any fullness. You did lose 1 meal.");
            }
            
            return RedirectToAction("Index");
        }

        [HttpGet("play")]
        public IActionResult Play()
        {
            Random r = new Random();
            Random c = new Random();
            int percent = c.Next(1,5);
            if(percent == 1)
            {
                int gained = r.Next(5,11);
                HttpContext.Session.SetString("action", "You played with your Dojodachi and gained " + gained + " happiness. You've also lost 5 energy.");
                int? oldhapp = HttpContext.Session.GetInt32("happiness");
                int newhapp = (int)oldhapp + gained;
                HttpContext.Session.SetInt32("happiness", newhapp);
            }
            else{
                HttpContext.Session.SetString("action", "You played with your Dojodachi and did not gain any happiness.");
            }

            int? oldenergy = HttpContext.Session.GetInt32("energy");
            oldenergy -= 5;
            HttpContext.Session.SetInt32("energy", (int)oldenergy);

            return RedirectToAction("Index");
        }
        
        [HttpGet("work")]
        public IActionResult Work()
        {
            Random r = new Random();
            int gained = r.Next(1,4);
            HttpContext.Session.SetString("action", "You worked your Dojodachi and gained " + gained + " meals. You've also lost 5 energy.");
            int? oldmeal = HttpContext.Session.GetInt32("meals");
            int newmeal = (int)oldmeal + gained;
            HttpContext.Session.SetInt32("meals", newmeal);
        
            int? oldenergy = HttpContext.Session.GetInt32("energy");
            int newenergy = (int)oldenergy - 5;
            HttpContext.Session.SetInt32("energy", newenergy);

            return RedirectToAction("Index");
        }

        [HttpGet("sleep")]
        public IActionResult Sleep()
        {
            int? oldenergy = HttpContext.Session.GetInt32("energy");
            int newenergy = (int)oldenergy - 15;
            HttpContext.Session.SetInt32("energy", newenergy);

            int? oldfull = HttpContext.Session.GetInt32("fullness");
            int newfull = (int)oldfull - 5;
            HttpContext.Session.SetInt32("fullness", newfull);

            int? oldhapp = HttpContext.Session.GetInt32("happiness");
            int newhapp = (int)oldhapp - 5;
            HttpContext.Session.SetInt32("happiness", newhapp);

            HttpContext.Session.SetString("action", "Your Dojodachi gained 15 energy, and lost 5 Fullness and Happiness.");
        
            return RedirectToAction("Index");
        }

    }
}
