using System;

namespace Dojodachi.Models
{
    public class MyModel
    {
       
    }
}