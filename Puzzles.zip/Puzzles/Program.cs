﻿using System;
using System.Collections.Generic;

namespace Puzzles
{
    class Program
    {
        static void Main(string[] args)
        {
            var test = Names();
            var coin = TossCoin();
            var mult = TossMultipleCoins(10);
            var ramdArray = RandomArray();
        }
        public static int[] RandomArray()
        {
            Random rand = new Random();
            int[] numbers = new int[10];

            for (var i=0;i<numbers.Length;i++)
            {
                numbers[i]=rand.Next(5,26);
            }
             
            int max = Int32.MinValue;
            int min = Int32.MaxValue;
            int sum = 0;

            foreach(var number in numbers)
            {
                sum += number;
                if(number > max)
                    max = number;
                if(number < min)
                    min = number;
            }
            Console.WriteLine($"Max: {max}");
            Console.WriteLine($"Min: {min}");
            Console.WriteLine($"Sum: {sum}");

            return numbers;
        }
        public static string TossCoin()
        {
            Console.WriteLine("Tossing a Coin!");

            Random rand = new Random();
            string result;

            if (rand.Next(2)==0)
                result = "Heads";
            else
                result = "Tails";

            Console.WriteLine($"The coin landed on: {result}");
            return result;
        }
        public static double TossMultipleCoins(int numToss)
        {
            Random rand = new Random();
            int heads = 0;

            for(var flip = 0; flip<numToss; flip++)
            {
                if (rand.Next(2)==0)
                    heads += 1;
            }
            double ratio = (double)heads/numToss;
            return ratio;
        }
        public static List<string> Names()
        {
            List<string> names = new List<string>()
            {
                "Todd", "Tiffany", "Charlie", "Geneva", "Sydmey"
            };

            List<string> randomNames = new List<string>();
            Random rand = new Random();
            int randomIndex = 0;
            
            while (names.Count > 0)
            {
                randomIndex = rand.Next(0, names.Count);
                randomNames.Add(names[randomIndex]);
                names.RemoveAt(randomIndex);
            }
            
            foreach(var name in randomNames)
            {
                Console.WriteLine(name);
            }

            for(var i=0; i<randomNames.Count; i++)
            {
                if(randomNames[i].Length <= 5)
                    randomNames.RemoveAt(i);
                // Console.WriteLine(randomNames[i]);
            }
            return randomNames;
        }
    }
}
