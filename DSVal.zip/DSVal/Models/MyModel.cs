using System;
using System.ComponentModel.DataAnnotations;

namespace DSVal.Models
{
    public class Survey
    {
        [Required]
        [MinLength(2, ErrorMessage="Name field must contain at least 2 characters.")]
        [Display(Name="Your Name:")]
        public string Name{get;set;}
        [Required]
        [Display(Name="Dojo Location:")]
        public string Location{get;set;}
        [Required]
        [Display(Name="Favorite Language")]
        public string Language{get;set;}
        [MaxLength(20, ErrorMessage="Comment should be no more than 20 characters.")]
        [Display(Name="Comment (optional):")]
        public string Comment{get;set;}
    }
}