using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
namespace PortfolioII.Controllers
{
    public class FirstController : Controller
    {
        [HttpGet("")]
        public ViewResult Index()
        {
            return View("index");
        }
        [HttpGet("projects")]
        public ViewResult Projects()
        {
            return View("projects");
        }
        [HttpGet("contact")]
        public ViewResult Contact()
        {
            return View("contact");
        }    
    }
}