using System;
using System.ComponentModel.DataAnnotations;

namespace FormSubmission.Models
{
    public class User
    {
       [Required]
       [MinLength(4, ErrorMessage="First name must be at least 4 characters.")]
       [Display(Name="First Name")]
       public string firstName{get;set;}
       [Required]
       [MinLength(4, ErrorMessage="Last name must be at least 4 characters.")]
       [Display(Name="Last Name")]
       public string lastName{get;set;}
       [Required]
       [Range(0,120, ErrorMessage="Age must be a positive number.")]
       public int Age{get;set;}
       [Required]
       [EmailAddress(ErrorMessage="Email address must be valid format (eg. abc123@somesite.com)")]
       [Display(Name="Email Address")]

       public string email{get;set;}
       [Required]
       [DataType(DataType.Password)]
       [MinLength(8, ErrorMessage="Password must be at least 8 characters long.")]
       public string Password{get;set;}
    }
}