using System;
using System.ComponentModel.DataAnnotations;

namespace MultForms.Models
{
    public class Register
    {
       [Required]
       [Display(Name="First Name")]
       [MinLength(2, ErrorMessage="First name must be at least 2 characters.")]
       public string firstName {get;set;}
       [Required]
       [Display(Name="Last Name")]
       [MinLength(2, ErrorMessage="Last name must be at least 2 characters.")]
       public string lastName {get;set;}
       [Required]
       [Display(Name="Email")]
       [EmailAddress(ErrorMessage="Email is not of valid format.")]
       public string emailAddress {get;set;}
       [Required]
       [Display(Name="Password")]
       [DataType(DataType.Password)]
       [MinLength(8, ErrorMessage="Password must be at least 8 characters.")]
       public string regPassword {get;set;}
       [Required]
       [Display(Name="Confirm Password")]
       [DataType(DataType.Password)]
       [Compare("regPassword", ErrorMessage="Passwords do not match.")]
       public string passConfirm {get;set;}

    }
    public class LogUser
    {
        [Required]
        [EmailAddress(ErrorMessage="Email is not of valid format.")]
        public string Email {get;set;}
        [Required]
        [DataType(DataType.Password)]
        public int Password {get;set;}
    }
}