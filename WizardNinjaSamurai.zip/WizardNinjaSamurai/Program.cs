﻿using System;

namespace WizardNinjaSamurai
{    
    class Human
    {
        public string Name;
        public int Strength;
        public int Intelligence;
        public int Dexterity;
        protected int health;
        public int Health
        {
            get { return health; }
            set{}
        }
        public Human(string name)
        {
            Name = name;
            Strength = 3;
            Intelligence = 3;
            Dexterity = 3;
            health = 100;
        }
        public Human(string name, int strength, int intelligence, int dexterity, int hp)
        {
            Name = name;
            Strength = strength;
            Intelligence = intelligence;
            Dexterity = dexterity;
            health = hp;
        }
        public virtual int Attack(Human target)
        {
            int dmg = Strength * 3;
            target.health -= dmg;
            Console.WriteLine($"{Name} has decreased {target.Name}'s health by {dmg}.");
            return target.health;
        }
        public virtual int Attack(Human target, int dmg)
        {
            target.health -= dmg;
            Console.WriteLine($"{Name} attacked {target.Name} for {dmg} damage!");
            return target.health;
        }
    }
    class Wizard : Human
    {
        public Wizard(string name, int str, int dex) : base(name)
        {
            Name = name;
            Strength = str;
            Intelligence = 25;
            Dexterity = dex;
            health = 50;
        }
        public override int Attack(Human target)
        {
            base.Attack(target, Intelligence*5);
            int damage = Intelligence*5;
            health += damage;
            Console.WriteLine($"{Name}'s health increased by {damage}.");
            return health;
        }
        public void Heal(Human target)
        {
            int heal = Intelligence * 10;
            target.Health += heal;
        }
    }
    class Ninja : Human
    {
        public Ninja(string name, int str, int intel, int hp) : base(name)
        {
            Name = name;
            Strength = str;
            Intelligence = intel;
            Dexterity = 175;
            health = hp;
        }
        public override int Attack(Human target)
        {
            Random rand = new Random();
            int dmg = Dexterity * 5;
            if(rand.Next(100)<20)
                dmg += 10;
            return base.Attack(target, dmg);
        }
        public void Steal(Human target)
        {
            target.Health -= 5;
            health += 5;
        }
    }
    class Samurai : Human
    {
        public Samurai(string name, int str, int intel, int dex) : base(name)
        {
            Name = name;
            Strength = str;
            Intelligence = intel;
            Dexterity = dex;
            health = 200;
        }
        public override int Attack(Human target)
        {
            int remaining = base.Attack(target);
            if (remaining < 50)
                target.Health = 0;
            Console.WriteLine($"{target.Name} has no health left.");
            return remaining;
        }
        public void Meditate()
        {
            health = 200;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Console.WriteLine("Hello World!");
        }
    }
}
