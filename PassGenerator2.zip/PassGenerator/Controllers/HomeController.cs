﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PassGenerator.Models;
using Microsoft.AspNetCore.Http;

namespace PassGenerator.Controllers
{
    public class HomeController : Controller
    {
        private string Generate(int size)
        {
            Random rand = new Random();
            string options = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            string outcome = "";
            for(var i=0; i< size; i++)
            {
                outcome += options[rand.Next(options.Length)];
            }
            return outcome;
        }
        [Route("")]
        [HttpGet]
        public IActionResult Index()
        {
            if(HttpContext.Session.GetString("passcode")==null)
            {
                HttpContext.Session.SetString("passcode", "Generate a passcode!");
            }
            if(HttpContext.Session.GetInt32("count")==null)
            {
                HttpContext.Session.SetInt32("count", 0);
            }
            ViewBag.Passcode = HttpContext.Session.GetString("passcode");
            ViewBag.Count = HttpContext.Session.GetInt32("count");

            return View();
        }

        [HttpGet("new")]
        public IActionResult New()
        {
            int? count = HttpContext.Session.GetInt32("count");
            count += 1;
            HttpContext.Session.SetInt32("count", (int)count);
            HttpContext.Session.SetString("passcode", Generate(14));
            return RedirectToAction("Index");
        }
        [HttpGet("clear")]
        public IActionResult Clear()
        {
            HttpContext.Session.SetInt32("count", 0);
            HttpContext.Session.SetString("passcode", "Generate a Passcode!");
            return RedirectToAction("Index");
        }
    }
}
