using System;

namespace PassGenerator.Models
{
    public class MyModel
    {
       
    }
}