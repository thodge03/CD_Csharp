﻿using System;

namespace FundamentalsI
{
    class Program
    {
        static void Main(string[] args)
        {
// For Loops
            for (int i=1; i <= 255; i++)
            {
                Console.WriteLine(i);
            }
            for (int x = 1; x <= 100; x++)
            {
                if (x%3 == 0 && x%5 != 0)
                {
                    Console.WriteLine(x);
                }
                else if (x%5 == 0 && x%3 != 0)
                {
                    Console.WriteLine(x);
                }
            }
            for (int z = 1; z <= 100; z++)
            {
                if  (z%3 == 0 &&  z%5 != 0)
                {
                    Console.WriteLine("Fizz");
                }
                else if (z%5 == 0 && z%3 != 0)
                {
                    Console.WriteLine("Buzz");
                }
                else if (z%3 == 0 && z%5 == 0)
                {
                    Console.WriteLine("FizzBuzz");
                }
            }
// While Loops:
            int c = 1;
            while (c < 256)
            {
                Console.WriteLine(c);
                c = c + 1;
            }
            int a = 1;
            while (a < 101)
            {
                if (a%3 == 0 && a%5 != 0)
                {
                    Console.WriteLine(a);
                    a = a + 1;
                }
                else if (a%5 == 0 && a%3 != 0)
                {
                    Console.WriteLine(a);
                    a = a + 1;
                }
                else
                {
                    a = a+1;
                }
            }
            int b = 1;
            while (b < 101)
            {
                if (b%3 == 0 && b%5 != 0)
                {
                    Console.WriteLine("Fizz");
                    b = b + 1;
                }
                else if (b%5 == 0 && b%3 != 0)
                {
                    Console.WriteLine("Buzz");
                    b = b + 1;
                }
                else if (b%5 == 0 && b%3==0)
                {
                    Console.WriteLine("FizzBuzz");
                    b = b+1;
                }
                else
                {
                    b = b+1;
                }
            }
        }
    }
}
