using System;
using System.ComponentModel.DataAnnotations;

namespace QuotingDOjo.Models
{
    public class Quote
    {
        [Required]
        [Display(Name="Your Name")]
        public string name {get;set;}
        [Required]
        [Display(Name="Your quote")]
        public string quote {get;set;}
    }
}