﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using QuotingDOjo.Models;

namespace QuotingDOjo.Controllers
{
    public class HomeController : Controller
    {
        [Route("")]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost("create")]
        public IActionResult Create(Quote newQuote)
        {
            if(ModelState.IsValid)
            {
                string query = $@"INSERT INTO quotes (name, quote, createdat) VALUES ('{newQuote.name}', '{newQuote.quote}', NOW())";
                DbConnector.Execute(query);
                return RedirectToAction("Quotes");
            }
            return View("Index");
        }

        [HttpGet("quotes")]
        public IActionResult Quotes()
        {
            string sql = $@"DELETE FROM quotes WHERE quote = ''";
            DbConnector.Execute(sql);
            ViewBag.Quotes = DbConnector.Query("SELECT * FROM quotes ORDER BY createdat DESC");
            return View();
        }
    }
}
