using System;

namespace ViewModelFun.Models
{
    public class User
    {
        public string FirstName{get;set;}
        public string LastName{get;set;}
    }
    public class Numbers
    {
        public int[] Int {get;set;}
    }
    public class Message
    {
        public string Content {get;set;}
    }
}