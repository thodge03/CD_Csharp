using System;

namespace ViewModelFun.Models
{
    public class MyModel
    {
       
    }
}