﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ViewModelFun.Models;

namespace ViewModelFun.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet("")]
        public IActionResult Index()
        {
            Message message = new Message()
            {
                Content = "This is a message that is intended for the index view of this assignment!"
            };
            return View(message);
        }
        [HttpGet("users")]
        public IActionResult Users()
        {
            User user1 = new User()
            {
                FirstName = "Tommy",
                LastName = "Jones"
            };
            User user2 = new User()
            {
                FirstName = "Sammy",
                LastName = "Smith"
            };
            User user3 = new User()
            {
                FirstName = "Lily",
                LastName = "Tompkins"
            };
            List<User> viewModel = new List<User>()
            {
                user1, user2, user3
            };
            return View(viewModel);
        }
        [HttpGet("user")]
        public IActionResult UserView()
        {
            User user4 = new User()
            {
                FirstName = "Kendall",
                LastName = "Jinglebells"
            };
            return View(user4);
        }
        [HttpGet("numbers")]
        public IActionResult Numbers()
        {
            int[] Int = {1,2,3,5,7};
            return View(Int);
        }
    }
}
