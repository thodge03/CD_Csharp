﻿using System;
using System.Collections.Generic;

namespace IronNinja
{    class Buffet
    {
        public List<IConsumable> Consumables;
         
        //constructor
        public Buffet()
        {
            Consumables = new List<IConsumable>()
            {
                new Food("Hershey's Bar", 1000, false, true),
                new Food("Chicken Breast", 300, false, false),
                new Food("Broccoli", 20, false, false),
                new Food("Lentil Soup", 500, false, false),
                new Food("Turkey Sandwich", 200, false, false),
                new Food("Hot Buffalo Wings", 1000, true, false),
                new Drink("Milkshake", 1000),
                new Drink("Mountain Dew", 320),
                new Drink("Water", 0)
            };
        }
         
        public IConsumable Serve()
        {
            Random rand = new Random();
            var randcon = Consumables[rand.Next(Consumables.Count)];
            return randcon;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Buffet b = new Buffet();
            SweetTooth sweet = new SweetTooth();
            SpiceHound spice = new SpiceHound();

            while (!sweet.IsFull)
                sweet.Consume(b.Serve());

            while (!spice.IsFull)
                spice.Consume(b.Serve());
            // Would have to insert this manually to repeat w/o interfering w/ conditional IsFull

            if (sweet.ConsumptionHistory.Count > spice.ConsumptionHistory.Count)
                Console.WriteLine($"SweetTooth consumed more items. {sweet.ConsumptionHistory.Count} to be exact!");
            else if (spice.ConsumptionHistory.Count > sweet.ConsumptionHistory.Count)
                Console.WriteLine($"SpiceHouse consumed more items. {spice.ConsumptionHistory.Count} to be exact!");
            else if (spice.ConsumptionHistory.Count == sweet.ConsumptionHistory.Count)
                Console.WriteLine($"They consumed the same number of items: {spice.ConsumptionHistory.Count}");        
        }
    }
}