using System;
using System.Collections.Generic;
namespace IronNinja
{
    abstract class Ninja
    {
        protected int calorieIntake;
        public List<IConsumable> ConsumptionHistory;
        public Ninja()
        {
            calorieIntake=0;
            ConsumptionHistory = new List<IConsumable>();
        }
        public abstract bool IsFull {get;}
        public abstract void Consume(IConsumable item);
    }
    class SweetTooth : Ninja
    {
        public override bool IsFull
        {
            get
            {
                return calorieIntake >=1500;
            }
        }
        public override void Consume(IConsumable randcon)
        {
            if (IsFull)
            {
                Console.WriteLine($"SweetTooth is full and cannot consume anymore!");
            }
            else
            {
                calorieIntake += randcon.Calories;
                if (randcon.IsSweet == true )
                    calorieIntake += 10;
                ConsumptionHistory.Add(randcon);
                Console.WriteLine("SweetTooth consumed: " + randcon.GetInfo());
            }   

        }
    }
    class SpiceHound : Ninja
    {
        public override bool IsFull
        {
            get
            {
                return calorieIntake >= 1200;
            }
        }
        public override void Consume(IConsumable randcon)
        {
            if (IsFull)
            {
                Console.WriteLine($"SpiceHound is full and cannot consume anymore!");
            }
            else
            {
                calorieIntake += randcon.Calories;
                if (randcon.IsSpicy == true )
                    calorieIntake -= 5;
                ConsumptionHistory.Add(randcon);
                Console.WriteLine("SpiceHound consumed: " + randcon.GetInfo());                
            }
        }
    }
}