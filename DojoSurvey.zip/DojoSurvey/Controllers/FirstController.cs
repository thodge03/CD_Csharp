using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace DojoSurvey.Controllers
{
    public class FirstController : Controller
    {
        [HttpGet("")]
        public ViewResult Index(){
            return View();
        }
        [HttpPost("survey")]
        public ViewResult submit(string name, string location, string language, string comment)
        {
            ViewBag.Name = name;
            ViewBag.location = location;
            ViewBag.language = language;
            ViewBag.comment = comment;
            return View("submit");
        }
    }
}