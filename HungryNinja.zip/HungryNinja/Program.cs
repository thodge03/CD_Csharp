﻿using System;
using System.Collections.Generic;

namespace HungryNinja
{
    class Food
    {
        public string Name;
        public int Calories;
        // Foods can be Spicy and/or Sweet
        public bool IsSpicy; 
        public bool IsSweet; 
        public Food(string name, int cal, bool spicy, bool sweet)
        {
            Name = name;
            Calories = cal;
            IsSpicy = spicy;
            IsSweet = sweet;
        }
    }
    class Buffet
    {
        public List<Food> Menu;
         
        //constructor
        public Buffet()
        {
            Menu = new List<Food>()
            {
                new Food("Hershey's Bar", 1000, false, true),
                new Food("Chicken Breast", 300, false, false),
                new Food("Broccoli", 20, false, false),
                new Food("Lentil Soup", 500, false, false),
                new Food("Milkshake", 1000, false, true),
                new Food("Turkey Sandwich", 200, false, false),
                new Food("Hot Buffalo Wings", 1000, true, false)
            };
        }
         
        public Food Serve()
        {
            Random rand = new Random();
            var randfood = Menu[rand.Next(Menu.Count)];
            Console.Write($"Food: {randfood.Name} Calories: {randfood.Calories}, Is Spicy: {randfood.IsSpicy}, Is Sweet: {randfood.IsSweet}");
            return randfood;
        }
    }
    class Ninja
    {
        private int calorieIntake;
        public List<Food> FoodHistory;
        public Ninja()
        {
            calorieIntake = 0;
            FoodHistory = new List<Food>();
        }
        public bool IsFull
        {
            get
            {
                if (calorieIntake > 1200)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public void Eat(Food randfood)
        {
            if(IsFull == false)
            {
                calorieIntake += randfood.Calories;
                FoodHistory.Add(randfood);
                Console.WriteLine($"Food: {randfood.Name} Spicy: {randfood.IsSpicy} Sweet: {randfood.IsSweet}");
                Console.WriteLine($"Current Calorie Intake: {calorieIntake}");           
            }
            else if(IsFull == true)
            {
                Console.Write("Ninja is full! He/She cannot eat more.");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Buffet b = new Buffet();
            Ninja n = new Ninja();
            while(n.IsFull == false)
                n.Eat(b.Serve());            
        }
    }
}
